package missdee

import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.JWSHeader
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jose.jwk.JWKSet
import com.nimbusds.jose.jwk.gen.RSAKeyGenerator
import com.nimbusds.jose.util.JSONObjectUtils
import com.nimbusds.jwt.JWTClaimsSet
import com.nimbusds.jwt.SignedJWT
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import java.util.*

const val fiveMinutes = 5 * 60 * 1000

val json = ContentType.parse("application/json")

suspend fun ApplicationCall.respondJson(text: String) = this.respondText(text, json)

/**
 * Generates a 2048-bit RSA JWK valid until the provided year.
 */
fun generateRsaKey(validUntilYear: Int) = RSAKeyGenerator(2048)
	.keyID("valid-until-$validUntilYear")
	.expirationTime(GregorianCalendar(2025, 0, 1).time)
	.generate()!!

object Keys {
	val validUntil2023 = generateRsaKey(2023)
	val validUntil2025 = generateRsaKey(2025)
	val validUntil2027 = generateRsaKey(2027)
}

val validKeySet = JWKSet(listOf(Keys.validUntil2025, Keys.validUntil2027))

fun main() {
	embeddedServer(Netty, port = 8080, module = {
		routing {
			/**
			 * This endpoint returns the JWK set of valid JWKs.
			 */
			get("/.well-known/jwks.json") {
				call.respondJson(
					JSONObjectUtils.toJSONString(validKeySet.toJSONObject())
				)
			}

			/**
			 * This endpoint returns a JWT; either signed with a valid key and valid for another five minutes, or signed with
			 * an expired key and valid until five minutes ago.
			 */
			post("/auth") {
				// Check for the expired query parameter.
				val expired = call.request.queryParameters.contains("expired")
				// Choose a valid or an expired key, depending on the expired query parameter.
				val key = if (expired) Keys.validUntil2023 else Keys.validUntil2025
				// Create the claim.
				val claimsSet = JWTClaimsSet.Builder()
					.subject("user")
					// Pick the expiration time depending on the expired query parameter.
					.expirationTime(if (expired) Date(Date().time - fiveMinutes) else Date(Date().time + fiveMinutes))
					.build()
				call.respondJson(
					// Create and sign the JWT.
					SignedJWT(JWSHeader.Builder(JWSAlgorithm.RS256).keyID(key.keyID).build(),  claimsSet)
						.apply { sign(RSASSASigner(key)) }
						.serialize()
				)
			}
		}
	}).start(wait = true)
}